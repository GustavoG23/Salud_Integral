SELECT * FROM sakai.pacientes;
