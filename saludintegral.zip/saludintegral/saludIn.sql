-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.11 - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para saludIn
CREATE DATABASE IF NOT EXISTS `saludIn` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `saludIn`;

-- Volcando estructura para tabla saludIn.paciente
CREATE TABLE IF NOT EXISTS `paciente` (
  `numeroPaciente` int(11) NOT NULL,
  `nombrePaciente` varchar(10) NOT NULL,
  `correoPaciente` varchar(8089) NOT NULL,
  `idDoctor` int(11) NOT NULL,
  PRIMARY KEY (`numeroPaciente`),
  KEY `Paciente_idDoctorr_fk` (`idDoctor`),
  CONSTRAINT `paciente_idDoctor_fk` FOREIGN KEY (`idDoctor`) REFERENCES `doctor` (`idDoctor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla saludIn.paciente: ~3 rows (aproximadamente)
INSERT INTO `paciente` (`numeroPaciente`, `nombrePaciente`,  `correoPaciente`,  `idDoctor`) VALUES
	(1, 'Gustavo Gaviria', '@gabo', 2),
	(2, 'Juan Rodríguez', 'juanda@', 3),
	(3, 'Gabriel Bedoya', 'gaby@', 5);
    
-- Volcando estructura para tabla saludIn.doctor
CREATE TABLE IF NOT EXISTS `doctor` (
  `idDoctor` int(11) NOT NULL,
  `nombreDoctor` varchar(80) NOT NULL,
  `correoDoctor` varchar(8089) NOT NULL,
  PRIMARY KEY (`idDoctor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla saludIn.doctor: ~7 rows (aproximadamente)
INSERT INTO `doctor` (`idDoctor`, `nombreDoctor`, `correoDoctor`) VALUES
	(1, 'Pedro Perez', 'pp@gmail.com'),
	(2, 'Luisa Lane', 'll@gmail.com'),
	(3, 'John Doe', 'jd1@gmail.com'),
	(4, 'Jean Doe', 'jd2@gmail.com'),
	(5, 'Nombre del proveedor', 'correo@gmail.com'),
	(6, 'Mario Mendoza', 'mm@gmail.com'),
	(9, 'Oscar Javier', 'nuevocorreo@gmail.com');

