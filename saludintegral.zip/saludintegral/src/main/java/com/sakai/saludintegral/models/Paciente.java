package com.sakai.saludintegral.models;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "paciente")
@Entity
@Data
public class Paciente implements Serializable {
@GeneratedValue(strategy = GenerationType.IDENTITY)  
     @Id
    @Column(name="numeroPaciente")
    private int numeroPaciente;
    @Column(name="nombrePaciente")
    private String nombrePaciente;
    @Column(name="correoPaciente")
    private String correoPaciente;
    @ManyToOne
    @JoinColumn(name="idDoctor")
    private Doctor doctor;

    public Paciente() {
    }

    public Paciente(int numeroPaciente, String nombrePaciente, String correoPaciente, Doctor doctor) {
        this.numeroPaciente = numeroPaciente;
        this.nombrePaciente = nombrePaciente;
        this.correoPaciente = correoPaciente;
        this.doctor = doctor;

    }


    public int getNumeroPaciente() {
        return numeroPaciente;
    }

    public void setNumeroPaciente(int numeroPaciente) {
        this.numeroPaciente = numeroPaciente;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) {
        this.nombrePaciente = nombrePaciente;
    }

    public String getTelefonoPaciente() {
        return correoPaciente;
    }

    public void setCorreoPaciente(String correoPaciente) {
        this.correoPaciente = correoPaciente;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
    
}
