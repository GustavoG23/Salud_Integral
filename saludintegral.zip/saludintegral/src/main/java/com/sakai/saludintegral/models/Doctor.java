
package com.sakai.saludintegral.models;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

@Table
@Entity(name="doctor")
public class Doctor implements Serializable{
      @Id
    @Column(name="idDoctor")
    private int idDoctor;
    @Column(name="nombreDoctor")
    private String nombreDoctor;
    @Column(name="correoDoctor")
    private String correoDoctor;

    public Doctor() {
    }

    public Doctor(int idDoctor, String nombreDoctor, String correoDoctor) {
        this.idDoctor = idDoctor;
        this.nombreDoctor = nombreDoctor;
        this.correoDoctor = correoDoctor;
    }

    public int getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(int idDoctor) {
        this.idDoctor = idDoctor;
    }

    public String getNombreDoctor() {
        return nombreDoctor;
    }

    public void setNombreDoctor(String nombreDoctor) {
        this.nombreDoctor = nombreDoctor;
    }

    public String getCorreoDoctor() {
        return correoDoctor;
    }

    public void setCorreoDoctor(String correoDoctor) {
        this.correoDoctor = correoDoctor;
    }
    
    
    
}
