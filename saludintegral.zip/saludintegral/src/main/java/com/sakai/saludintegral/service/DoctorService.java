/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sakai.saludintegral.service;

import com.sakai.saludintegral.models.Doctor;
import java.util.List;


public interface DoctorService {

    public Doctor save(Doctor doctor);

    public Doctor findById(Integer id);

    public void delete(Integer id);

    public List<Doctor> findByAll();
    
    
    
}
