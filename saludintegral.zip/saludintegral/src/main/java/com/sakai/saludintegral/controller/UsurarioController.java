
package com.sakai.saludintegral.controller;



import java.util.ArrayList;
import java.util.Optional;

import com.sakai.saludintegral.SaludintegralApplication;

import com.sakai.saludintegral.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/usuario")
public class UsurarioController {
    
   
    
}
