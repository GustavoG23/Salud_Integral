
package com.sakai.saludintegral.service;

import com.sakai.saludintegral.models.Paciente;
import java.util.List;


public interface PacienteService {
    
     public Paciente save(Paciente paciente);
    public void delete(Integer id);
    public Paciente findById(Integer id);

    /**
     *
     * @return
     */
    public List<Paciente> findByAll();
    
}
