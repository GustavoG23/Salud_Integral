
package com.sakai.saludintegral.controller;

import com.sakai.saludintegral.models.Paciente;

import com.sakai.saludintegral.service.PacienteService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin("*")
@RequestMapping("/paciente")
public class PacienteController {
   @Autowired
    private PacienteService pacienteService;
    
     @PostMapping(value="/")
    public ResponseEntity<Paciente> agregar(@RequestBody Paciente paciente){
        Paciente obj = pacienteService.save(paciente);
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    @GetMapping("/list")
    public List<Paciente> consultarTodo(){
        return pacienteService.findByAll();
    }
    
    @GetMapping("/list/{id}")
    public Paciente consultarPorId(@PathVariable Integer id){
        return pacienteService.findById(id);
    }

}
