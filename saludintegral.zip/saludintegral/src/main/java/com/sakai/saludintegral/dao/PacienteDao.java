
package com.sakai.saludintegral.dao;

import com.sakai.saludintegral.models.Paciente;
import org.springframework.data.repository.CrudRepository;


public interface PacienteDao extends CrudRepository<Paciente, Integer>{
    
    
    
}
