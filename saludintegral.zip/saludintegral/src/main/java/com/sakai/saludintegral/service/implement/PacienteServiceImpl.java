
package com.sakai.saludintegral.service.implement;

import com.sakai.saludintegral.dao.PacienteDao;
import com.sakai.saludintegral.models.Paciente;
import com.sakai.saludintegral.service.PacienteService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PacienteServiceImpl implements PacienteService{
    
    @Autowired
    private PacienteDao pacienteDao;

    @Override
    public Paciente save(Paciente paciente) {
       
        return pacienteDao.save(paciente);
    }

    @Override
    public void delete(Integer id) {
     pacienteDao.deleteById(id);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    @Transactional(readOnly=true)
    public Paciente findById(Integer id){
        return pacienteDao.findById(id).orElse(null);
    }

    @Override
    public List<Paciente> findByAll() {
        return (List<Paciente>)pacienteDao.findAll();
    }
    
    
}
