
package com.sakai.saludintegral.dao;

import com.sakai.saludintegral.models.Doctor;
import org.springframework.data.repository.CrudRepository;


public interface DoctorDao extends CrudRepository<Doctor, Integer> {
    
}
